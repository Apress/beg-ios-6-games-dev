//
//  Sample_03AppDelegate_iPhone.m
//  Sample 03
//
//  Created by Lucas Jordan on 4/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Sample_03AppDelegate_iPhone.h"

@implementation Sample_03AppDelegate_iPhone

- (void)dealloc
{
	[super dealloc];
}

@end
