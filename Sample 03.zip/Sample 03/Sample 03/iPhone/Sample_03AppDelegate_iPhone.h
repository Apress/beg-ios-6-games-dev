//
//  Sample_03AppDelegate_iPhone.h
//  Sample 03
//
//  Created by Lucas Jordan on 4/6/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Sample_03AppDelegate.h"

@interface Sample_03AppDelegate_iPhone : Sample_03AppDelegate {
    
}

@end
