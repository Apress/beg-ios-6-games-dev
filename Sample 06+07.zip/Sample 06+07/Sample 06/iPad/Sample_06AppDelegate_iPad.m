//
//  Sample_06AppDelegate_iPad.m
//  Sample 06
//
//  Created by Lucas Jordan on 5/14/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Sample_06AppDelegate_iPad.h"

@implementation Sample_06AppDelegate_iPad


@end
